package com.example.springmvc.service;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.springmvc.dao.IPOPlannedDao;
import com.example.springmvc.model.IPODetail;
@Service
public class IPOPlannedServiceImpl implements IPOPlannedService{
@Autowired
private IPOPlannedDao ipoPlannedDao;
	public IPODetail insertIPODetail(IPODetail ipoDetail) {
		// TODO Auto-generated method stub
		System.out.println("Inside service");
		ipoPlannedDao.save(ipoDetail);
		
		return null;
	}

	public List<IPODetail> getIPODetais() throws SQLException {
		// TODO Auto-generated method stub
		return ipoPlannedDao.findAll();
	}

}
