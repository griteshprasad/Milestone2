package com.example.springmvc.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import javax.swing.*;

/*import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.JOptionPane;
*/
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.example.springmvc.model.User;
import com.example.springmvc.service.UserService;

@Controller
public class UserControllerImpl implements UserController {
	@Autowired
	private UserService userService;



	public void setUserService(UserService userService) {
		this.userService = userService;
	}


	@RequestMapping(value="/userRegister")
	public String registration(User user,ModelMap model) {
		model.addAttribute("user",user);
		return "userRegistration";
	}
	@RequestMapping(value="/userLogin")
	public String userLogin()
	{
		return "userLogin";
	}

	@Override
	@RequestMapping(value="/addUser",method=RequestMethod.POST)
	public String insertUser(@ModelAttribute("user") @Validated User user) throws SQLException {
		// TODO Auto-generated method stub
		System.out.println("Registerd");
		/*user.setUserName(request.getParameter("name"));
		user.setPassword(request.getParameter("password"));
		user.setE_mail(request.getParameter("email"));
		user.setMobileNumber(request.getParameter("mobile"));
		System.out.println(user.getE_mail());*/
		//JOptionPane.showMessageDialog(null, "Your details are submitted successfully");

	userService.insertUser(user);
	return "userLogin";
			
	}
            
	
	@RequestMapping(value="/userValidate")
	public String validateUser(HttpServletRequest request, HttpServletResponse response) throws Exception {
        response.setContentType("text/html");
        
        System.out.println("welcome");
       String userName=request.getParameter("userName");
       System.out.print(userName);
        String password=request.getParameter("password");
        User u=new User(userName,password);
        System.out.println(u.getUserName()+""+u.getPassword());
       int i= userService.validateUser(u);
       if(i!=0) {
    		HttpSession session=request.getSession();
    		session.setAttribute("userName", userName);
			System.out.println(userName);
    		return "userLandingPage";
    	     	  
    		}
    	   
   		
       
       else
       {/*
    	   JFrame f;  
    	
    	       f=new JFrame();  
    	       JOptionPane.showMessageDialog(f,"Invalid UserName or Password!");  */
    	  
	return "userLogin";
	}
	
}

	public List<User> getUserList() throws Exception {
		// TODO Auto-generated method stub
		return userService.getUserList();
			}
	
	public static void main(String [] args) {
		//CompanyController companyController=new CompanyControllerImpl();
		UserController userController=new UserControllerImpl();
		
		try {
			System.out.println(userController.getUserList());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}




	@Override
	public User updateUser(User user) {
		// TODO Auto-generated method stub
		return null;
	}




	

}
