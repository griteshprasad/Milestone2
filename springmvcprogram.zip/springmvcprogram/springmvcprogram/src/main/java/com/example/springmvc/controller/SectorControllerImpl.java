package com.example.springmvc.controller;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.springmvc.model.Sector;
import com.example.springmvc.service.SectorService;
@Controller
public class SectorControllerImpl implements SectorController {
@Autowired
private SectorService sectorService;

@Override
@RequestMapping(value="/compareSector")
public String compareSector() {
	return "compareSector";
}
	@Override
	public Sector insertSector(Sector sector) {
		// TODO Auto-generated method stub
		sectorService.insertSector(sector);
		return null;
	}

	@Override
	public List<Sector> getSector() throws SQLException {

		sectorService.getSector();
		// TODO Auto-generated method stub
		return null;
	}
	public static void main(String[] args) throws SQLException {
		System.out.println("before the container");
		Sector sector=new Sector();
		//company.setBoardOfDirectors("df");
		//company.setCompany_code(1001);
		ApplicationContext applicationContext=new ClassPathXmlApplicationContext("spring.xml");
		System.out.println("after the container");
		SectorController sectorController=(SectorController)applicationContext.getBean("sectorControllerImpl");
		sectorController.insertSector(sector);		
		sectorController.getSector();
	}

}
