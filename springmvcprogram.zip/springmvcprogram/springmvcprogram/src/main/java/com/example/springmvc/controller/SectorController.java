package com.example.springmvc.controller;

import java.sql.SQLException;
import java.util.List;

import com.example.springmvc.model.Sector;

public interface SectorController {
	public Sector insertSector(Sector sector);
	public List<Sector> getSector() throws SQLException;
	String compareSector();

}
